var canvas = new fabric.canvas('myCanvas');

block_image_width = 30
block_image_hieght = 30

player_x = 10
player_y = 10

var player_objects= "";

function player_update()
{
    fabric.image.fromURL("player.png", function(Img) {
        player_object.scaleToWidth(150)
        player_object.scaleToHeight(140)
    player_object.set({
    top:player_y 
    left:player_x    
    });
    canvas.add(player_object);

        